<!DOCTYPE html>
<html lang="es">
<head>
<?php include_once("scripts.php"); ?>
</head>
<body>
    <?php include_once("header.php"); ?>


    <br>

</body>
</html>