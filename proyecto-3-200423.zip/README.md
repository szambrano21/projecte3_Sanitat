# GIT

### Commands of new branch in git

`git checkout -b yourbranch `

### Change of branch

`git checkout yourbranch`

### Merge of branch an other branch

`git merge main yourbranch`

